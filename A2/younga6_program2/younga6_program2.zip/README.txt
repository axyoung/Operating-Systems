---README---
Alex Young
To compile this code to create an executable file named 'movies_by_year' use:
gcc --std=gnu99 -o movies_by_year main.c
Run the executable with ./movies_by_year