---README---
Alex Young
To compile this code to create an executable file named 'smallsh' use:
gcc --std=gnu99 -o smallsh main.c
Run the executable with ./smallsh