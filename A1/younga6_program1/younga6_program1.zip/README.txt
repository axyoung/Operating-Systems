---README---
Alex Young
To compile this code to create an executable file named 'movies' use:
gcc --std=gnu99 -o movies main.c
Run the executable with ./movies filename.csv (filename being the correct file name)