---README---
Alex Young
To compile this code to create an executable file named 'line_processor' use:
gcc --std=gnu99 -pthread -o line_processor main.c
Run the executable with ./line_processor